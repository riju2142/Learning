import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { PeopleService } from '../people.service';
import { Person } from '../person';

@Component({
  selector: 'app-person-details',
  templateUrl: './person-details.component.html',
  // template: `
  //   <section *ngIf="person">
  //     <h2>You selected:  {{person.name}}</h2>
  //     <h3>Description</h3>
  //     <p>
  //       {{person.name}} weights  {{person.weight}} and is  {{person.height}} tall.
  //     </p>
  //   </section>
  //   <! -- NEW BUTTON HERE! -->
  //   <button (click)="gotoPeoplesList()">Back to peoples list</button>
  // `,
  styles: ['./person-details.component.css']
})
export class PersonDetailsComponent implements OnInit {
  // update PersonDetailsComponent
  // to decorate the person property with @Input()
  //@Input() person : Person;
  person : Person;
  sub: any;

  constructor(private peopleService: PeopleService,
               private route: ActivatedRoute) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      let id = Number.parseInt(params['id']);
      this.person = this.peopleService.get(id);
    });
  }

  ngOnDestroy(): void {
      this.sub.unsubscribe();
  }

  savePersonDetails(){
      alert(`saved!!! ${JSON.stringify(this.person)}`);
  }

  gotoPeoplesList(){
      window.history.back();
  }
}
