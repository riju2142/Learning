import { Component, OnInit } from '@angular/core';
import { Person } from '../person';
import { PeopleService } from "app/people.service";
import { PersonDetailsComponent } from '../person-details/person-details.component'

@Component({
  selector: 'app-people-list',
  template: `
    <ul class="people-list"
      *ngFor="let person of people">
      <li class="person">
        <!-- HERE: add a element with click event binding -->
        <a href="#" 
          <!-- (click)="selectPerson(person)" -->
          [routerLink]="['/persons', person.id]">
          {{person.name}}
        </a>
      </li>
    </ul>

  <!-- HERE: we add the template for the person details -->
  <app-person-details [person] = "selectedPerson"></app-person-details>
  `,
  styleUrls: ['./people-list.component.scss']
})
export class PeopleListComponent implements OnInit {
  people:Person[];
  selectedPerson: Person; 

  constructor(public peopleService:PeopleService) {}

  ngOnInit() {
    this.people = this.peopleService.getAll();
  }

  // selectPerson(person:Person) {
  //   this.selectedPerson = person;
  // }

}
