module.exports = require('./lib/entry').default;
