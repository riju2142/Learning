declare const observableSymbol: symbol;
export default observableSymbol;
