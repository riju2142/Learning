var core = require('./lib/core');
var async = require('./lib/async');
async.core = core;
async.isCore = function isCore(x) { return core[x]; };
async.sync = require('./lib/sync');

exports = async;
module.exports = async;
