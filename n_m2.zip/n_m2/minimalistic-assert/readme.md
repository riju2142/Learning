minimalistic-assert
===

very minimalistic assert module.
