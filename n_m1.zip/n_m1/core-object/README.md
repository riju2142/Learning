### CoreObject

[![Travis CI](https://img.shields.io/travis/ember-cli/core-object/master.svg)](https://travis-ci.org/ember-cli/core-object)

A lightweight implementation of OOP Class in JavaScript. It is currently used in
[ember-cli](https://github.com/ember-cli/ember-cli).
